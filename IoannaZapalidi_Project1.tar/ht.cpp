#include "ht.h"

ht_node::ht_node(/* args */)
{
}

ht_node::~ht_node()
{
}




////ht implementations
ht::ht(/* args */) {

}

ht::~ht() {}

int ht::hash_fun(/* sth*/) {

}